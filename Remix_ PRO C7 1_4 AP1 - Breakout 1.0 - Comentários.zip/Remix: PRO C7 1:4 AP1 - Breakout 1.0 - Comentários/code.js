var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["eb8af59a-3972-464f-a7e0-fafa22930322","d296553b-b17f-4b69-8de0-27322b6da49a"],"propsByKey":{"eb8af59a-3972-464f-a7e0-fafa22930322":{"name":"robozin","sourceUrl":"assets/api/v1/animation-library/gamelab/xDyMqDai99fWCOEzsHFdPBAsnNudKKMk/category_retro/spacebattle_04.png","frameSize":{"x":174,"y":122},"frameCount":1,"looping":true,"frameDelay":2,"version":"xDyMqDai99fWCOEzsHFdPBAsnNudKKMk","categories":["retro"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":174,"y":122},"rootRelativePath":"assets/api/v1/animation-library/gamelab/xDyMqDai99fWCOEzsHFdPBAsnNudKKMk/category_retro/spacebattle_04.png"},"d296553b-b17f-4b69-8de0-27322b6da49a":{"name":"space","sourceUrl":"assets/api/v1/animation-library/gamelab/qoFFPgWiydir6HZwldQy.Fmh8NmNhTI9/category_backgrounds/background_space.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"qoFFPgWiydir6HZwldQy.Fmh8NmNhTI9","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/qoFFPgWiydir6HZwldQy.Fmh8NmNhTI9/category_backgrounds/background_space.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----


var gamestate = "lançar";
var score = 0
//criando raquete e bola
var space1 = createSprite(200,200,400,400)
var paddle = createSprite(200, 375, 100, 15);
paddle.shapeColor="white"
var ball = createSprite(150, 250, 20, 20);


//primeira linha de caixas
var box1 = createSprite(25, 75, 50, 50);
box1.shapeColor="blue";
var box2 = createSprite(75, 75, 50, 50);
box2.shapeColor="purple";
var box3 = createSprite(125, 75, 50, 50);
box3.shapeColor="blue";
var box4 = createSprite(175, 75, 50, 50);
box4.shapeColor="purple";
var box5 = createSprite(225, 75, 50, 50);
box5.shapeColor="blue";
var box6 = createSprite(275, 75, 50, 50);
box6.shapeColor="purple";
var box7 = createSprite(325, 75, 50, 50);
box7.shapeColor="blue";
var box8 = createSprite(375, 75, 50, 50);
box8.shapeColor="purple";

//segunda linha de caixas
var box9 = createSprite(25, 125, 50, 50);
box9.shapeColor="purple";
var box10 = createSprite(75, 125, 50, 50);
box10.shapeColor="blue";
var box11 = createSprite(125, 125, 50, 50);
box11.shapeColor="purple";
var box12 = createSprite(175, 125, 50, 50);
box12.shapeColor="blue";
var box13 = createSprite(225, 125, 50, 50);
box13.shapeColor="purple";
var box14 = createSprite(275, 125, 50, 50);
box14.shapeColor="blue";
var box15 = createSprite(325, 125, 50, 50);
box15.shapeColor="purple";
var box16 = createSprite(375, 125, 50, 50);
box16.shapeColor="blue";

space1.setAnimation("space")
ball.setAnimation("robozin")
ball.scale =0.30
//
function draw() {
  background("white");
  drawSprites();
  
 stroke("white");
 textSize(20);
 text("pontuação: "+score, 190, 200);
  
  if (gamestate=="lançar") {
    text("aperte enter para jogar", 190, 200);
    if(keyDown("enter")){
    ball.velocityX = 3;
    ball.velocityY = 4;
    gamestate="play"
    }
  }
  if (gamestate=="play") {
    if (ball.isTouching(box1)) {
    box1.destroy();
    score = score+1
  }
  if (ball.isTouching(box2)) {
    box2.destroy();
    score = score +1
  }
  if (ball.isTouching(box3)) {
    box3.destroy();
    score = score+1
  }
  if (ball.isTouching(box4)) {
    box4.destroy();
    score = score+1
  }
  if (ball.isTouching(box5)) {
    box5.destroy();
    score = score+1
  }
  if (ball.isTouching(box6)) {
    box6.destroy();
    score = score+1
  }
  if (ball.isTouching(box7)) {
    box7.destroy();
    score = score+1
  }
  if (ball.isTouching(box8)) {
    box8.destroy();
    score = score+1
  }
  if (ball.isTouching(box9)) {
    box9.destroy();
    score = score+1
  }
  if (ball.isTouching(box10)) {
    box10.destroy();
    score = score+1
  }
  if (ball.isTouching(box11)) {
    box11.destroy();
    score = score+1
  }
  if (ball.isTouching(box12)) {
    box12.destroy();
    score = score+1
  }
  if (ball.isTouching(box13)) {
    box13.destroy();
    score = score+1
  }
  if (ball.isTouching(box14)) {
    box14.destroy();
    score = score+1
  }
  if (ball.isTouching(box15)) {
    box15.destroy();
    score = score+1
  }
  if (ball.isTouching(box16)) {
    box16.destroy();
    score = score+1
  }
  }
  if (gamestate=="end") {
    text("fim de jogo", 0, 15);
    
  }
  
  
  //mover a bola ao pressionar a tecla enter
  
  

  
  //fazer a bola rebater na raquete e em três lados da tela
  createEdgeSprites();
  ball.bounceOff(rightEdge);
  ball.bounceOff(leftEdge);
  ball.bounceOff(topEdge);
  ball.bounceOff(paddle);

 if (ball.isTouching(bottomEdge)) {
    textSize(35);
    stroke("white");
    text("you lose", 145, 250);
    
  }
  if (score===16) {
    textSize(35);
    stroke("white");
    text("you win", 145, 250);
  }
  
  //mover a raquete com o mouse ao longo do eixo x
  paddle.x=World.mouseX;

}




// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
